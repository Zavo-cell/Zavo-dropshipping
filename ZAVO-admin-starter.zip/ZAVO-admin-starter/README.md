# ZAVO Dropshipping — Admin Starter

ZAVO starter project for a mobile-friendly admin dashboard, a basic storefront landing page, a Cloudflare Worker API, and Cloudflare D1 database.

## Files
- `public/index.html` — public starter page
- `public/admin.html` — private admin sign-in and dashboard
- `src/index.js` — backend API and signed admin session cookie
- `schema.sql` — database tables
- `wrangler.jsonc` — Cloudflare Worker + static assets + D1 configuration

## Before you publish
This is a starter foundation, not a finished live marketplace. It does not yet take customer orders, process or verify payments, issue refunds, upload product images, or calculate reseller commissions. Do not accept real payments until checkout, payment verification, supplier fulfilment and returns have been built and tested.

## Deploy using Cloudflare
1. Upload these files and folders to your GitHub repository, keeping the folder structure unchanged.
2. In Cloudflare, open **Workers & Pages** and create a Worker using your GitHub repository / Workers Builds.
3. Cloudflare can provision the D1 resource named `zavo-marketplace-db` from `wrangler.jsonc`. If the dashboard asks you to create it separately, create a D1 database with that name and add a D1 binding named exactly `DB`.
4. Open **D1** → `zavo-marketplace-db` → **Console**. Paste the full contents of `schema.sql` and run it once.
5. In the Worker settings, open **Settings → Variables and Secrets** and add these as secrets (not plain text variables):
   - `ADMIN_PASSWORD` — choose a long, unique admin password.
   - `SESSION_SECRET` — a different, random secret of at least 32 characters.
6. Deploy / retry the latest build.
7. Open `https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev/admin.html` and sign in with `ADMIN_PASSWORD`.
8. Test by adding one draft product and one supplier.

## Important security notes
- Never put your admin password, session secret, payment keys, or supplier credentials in GitHub files.
- Admin login uses a signed, HttpOnly, Secure, SameSite=Strict cookie with an eight-hour expiry.
- Before a public production launch, add rate limiting to login, stronger operational monitoring, backups, and a review of security and privacy requirements.
- If you change the Worker configuration in the Cloudflare dashboard, keep it consistent with `wrangler.jsonc`.
