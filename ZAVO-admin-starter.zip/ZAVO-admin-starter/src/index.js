const json = (data, status = 200, extraHeaders = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...extraHeaders }
  });

const encoder = new TextEncoder();
const b64url = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes)))
  .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
const fromB64url = (str) => {
  const padded = str.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - str.length % 4) % 4);
  return Uint8Array.from(atob(padded), c => c.charCodeAt(0));
};

async function sign(value, secret) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64url(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}
async function verifyToken(token, secret) {
  if (!token || !secret) return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const expected = await sign(parts[0], secret);
  if (expected !== parts[1]) return false;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
    return payload.exp > Math.floor(Date.now() / 1000);
  } catch { return false; }
}
function cookieValue(request, name) {
  const cookie = request.headers.get("Cookie") || "";
  const match = cookie.split(";").map(x => x.trim()).find(x => x.startsWith(name + "="));
  return match ? match.slice(name.length + 1) : "";
}
async function isAdmin(request, env) {
  return verifyToken(cookieValue(request, "zavo_admin"), env.SESSION_SECRET);
}
function cookieHeader(value, maxAge) {
  return `zavo_admin=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
async function bodyJson(request) {
  try { return await request.json(); } catch { return null; }
}
const clean = (value, max = 500) => String(value ?? "").trim().slice(0, max);
const integer = (value, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.round(n)) : fallback;
};
async function audit(env, action, type, id = "") {
  await env.DB.prepare("INSERT INTO admin_audit_log (id, action, item_type, item_id) VALUES (?, ?, ?, ?)")
    .bind(crypto.randomUUID(), action, type, id).run();
}
async function requireDb(env) {
  if (!env.DB) throw new Error("D1 database binding DB is missing. Add it in Cloudflare Worker settings.");
}
async function handleApi(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  if (path === "/api/health" && method === "GET") {
    return json({ success: true, status: "ok", service: "ZAVO API" });
  }

  if (path === "/api/admin/login" && method === "POST") {
    if (!env.ADMIN_PASSWORD || !env.SESSION_SECRET) {
      return json({ success: false, error: "Admin secrets are not configured in Cloudflare." }, 503);
    }
    const body = await bodyJson(request);
    if (!body || typeof body.password !== "string" || body.password !== env.ADMIN_PASSWORD) {
      return json({ success: false, error: "Incorrect password." }, 401);
    }
    const payload = b64url(encoder.encode(JSON.stringify({ exp: Math.floor(Date.now() / 1000) + 60 * 60 * 8 })));
    const token = `${payload}.${await sign(payload, env.SESSION_SECRET)}`;
    return json({ success: true }, 200, { "set-cookie": cookieHeader(token, 60 * 60 * 8) });
  }

  if (path === "/api/admin/logout" && method === "POST") {
    return json({ success: true }, 200, { "set-cookie": cookieHeader("", 0) });
  }

  if (path === "/api/admin/me" && method === "GET") {
    return (await isAdmin(request, env)) ? json({ success: true, admin: true }) : json({ success: false }, 401);
  }

  if (!path.startsWith("/api/admin/")) return json({ success: false, error: "API route not found." }, 404);
  if (!(await isAdmin(request, env))) return json({ success: false, error: "Please sign in as admin." }, 401);

  try {
    await requireDb(env);

    if (path === "/api/admin/summary" && method === "GET") {
      const [products, orders, suppliers, revenue, latest] = await Promise.all([
        env.DB.prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status='published' THEN 1 ELSE 0 END) AS published, SUM(CASE WHEN stock<=5 THEN 1 ELSE 0 END) AS low_stock FROM products").first(),
        env.DB.prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending FROM orders").first(),
        env.DB.prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) AS active FROM suppliers").first(),
        env.DB.prepare("SELECT COALESCE(SUM(total_kes),0) AS total FROM orders WHERE payment_status='paid'").first(),
        env.DB.prepare("SELECT id, order_number, customer_name, total_kes, status, payment_status, created_at FROM orders ORDER BY created_at DESC LIMIT 6").all()
      ]);
      return json({ success: true, summary: {
        products: products.total || 0, published: products.published || 0, lowStock: products.low_stock || 0,
        orders: orders.total || 0, pendingOrders: orders.pending || 0,
        suppliers: suppliers.total || 0, activeSuppliers: suppliers.active || 0,
        revenueKes: revenue.total || 0, recentOrders: latest.results || []
      }});
    }

    if (path === "/api/admin/products" && method === "GET") {
      const search = `%${clean(url.searchParams.get("search"), 100)}%`;
      const result = await env.DB.prepare(
        "SELECT * FROM products WHERE title LIKE ? OR category LIKE ? ORDER BY created_at DESC LIMIT 200"
      ).bind(search, search).all();
      return json({ success: true, products: result.results || [] });
    }

    if (path === "/api/admin/products" && method === "POST") {
      const body = await bodyJson(request);
      const title = clean(body?.title, 160);
      if (!title) return json({ success: false, error: "Product title is required." }, 400);
      const id = crypto.randomUUID();
      await env.DB.prepare(`INSERT INTO products
        (id,title,description,category,image_url,cost_kes,price_kes,stock,status)
        VALUES (?,?,?,?,?,?,?,?,?)`)
        .bind(id, title, clean(body.description, 3000), clean(body.category, 80) || "General",
          clean(body.image_url, 1000), integer(body.cost_kes), integer(body.price_kes), integer(body.stock),
          ["draft","published","archived"].includes(body.status) ? body.status : "draft").run();
      await audit(env, "created", "product", id);
      return json({ success: true, id }, 201);
    }

    const productMatch = path.match(/^\/api\/admin\/products\/([^/]+)$/);
    if (productMatch && method === "PATCH") {
      const body = await bodyJson(request);
      const id = decodeURIComponent(productMatch[1]);
      const existing = await env.DB.prepare("SELECT * FROM products WHERE id=?").bind(id).first();
      if (!existing) return json({ success: false, error: "Product not found." }, 404);
      const p = { ...existing, ...body };
      if (!clean(p.title,160)) return json({ success: false, error: "Product title is required." }, 400);
      await env.DB.prepare(`UPDATE products SET title=?, description=?, category=?, image_url=?, cost_kes=?, price_kes=?, stock=?, status=? WHERE id=?`)
        .bind(clean(p.title,160), clean(p.description,3000), clean(p.category,80) || "General", clean(p.image_url,1000),
          integer(p.cost_kes), integer(p.price_kes), integer(p.stock),
          ["draft","published","archived"].includes(p.status) ? p.status : "draft", id).run();
      await audit(env, "updated", "product", id);
      return json({ success: true });
    }

    if (path === "/api/admin/suppliers" && method === "GET") {
      const result = await env.DB.prepare("SELECT * FROM suppliers ORDER BY created_at DESC LIMIT 200").all();
      return json({ success: true, suppliers: result.results || [] });
    }
    if (path === "/api/admin/suppliers" && method === "POST") {
      const body = await bodyJson(request);
      const name = clean(body?.name, 160);
      if (!name) return json({ success: false, error: "Supplier name is required." }, 400);
      const id = crypto.randomUUID();
      await env.DB.prepare("INSERT INTO suppliers (id,name,contact,country,notes,status) VALUES (?,?,?,?,?,?)")
        .bind(id, name, clean(body.contact,200), clean(body.country,100) || "Kenya", clean(body.notes,1000),
          ["pending","active","paused"].includes(body.status) ? body.status : "pending").run();
      await audit(env, "created", "supplier", id);
      return json({ success: true, id }, 201);
    }

    if (path === "/api/admin/orders" && method === "GET") {
      const result = await env.DB.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 200").all();
      return json({ success: true, orders: result.results || [] });
    }

    if (path === "/api/admin/audit" && method === "GET") {
      const result = await env.DB.prepare("SELECT * FROM admin_audit_log ORDER BY created_at DESC LIMIT 50").all();
      return json({ success: true, events: result.results || [] });
    }

    return json({ success: false, error: "API route not found." }, 404);
  } catch (error) {
    return json({ success: false, error: error?.message || "Server error." }, 500);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) return handleApi(request, env);
    return env.ASSETS.fetch(request);
  }
};
